package com.folders.example.files_and_folders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilesAndFoldersApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilesAndFoldersApplication.class, args);
	}

}
